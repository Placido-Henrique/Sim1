package sim1;

public class Corredor {
	private String nome;
	private String cpf;
	private int anoDeNascimento;
	private int contador = 0;
	private Treino[] treinos;
	private int treinosFinalizados = 0;
	private double resistencia = 0;
	
	public Corredor (String nome,String cpf,int anoDeNascimento) {
		this.nome = nome;
		this.cpf = cpf;
		this.anoDeNascimento = anoDeNascimento;
		this.treinos = new Treino[100];
	}
	
	public String toStr() {
		return nome + " - " + cpf + " - " + anoDeNascimento +" - "+ this.exibirCategoriaCorredor(cpf);
	}
	
	public String  exibirCategoriaCorredor(String cpf) {
		int idade = 2019 - this.anoDeNascimento;
		
		if (15<=idade && idade<=24) {
			return "JOVEM";
		}
		
		else if (24<idade && idade<=40) {
			return "ADULTO";
		}
		else if (40<idade && idade<=64) {
			return "SUPER_ADULTO";
		}
		else {
			return "MELHOR_IDADE";
		}
	}
	
	public String getCpf(){
		return this.cpf;
	}
	
	public void cadastraTreino(double distancia,int tempoEsperado,String descricao){
		this.treinos[contador] = new Treino(contador,distancia,tempoEsperado, descricao);
		contador ++;
		
	}
	
	public void finalizaTreino(int indice, int tempoGasto) {
		this.treinos[indice].finalizar(tempoGasto);
		treinosFinalizados ++;
		
		int total  = 0;
		int elementos = this.treinos.length;
		double media = 0;
		for (int i = 0;i < 100; i++) {
			total += this.treinos[i].getResistencia();
		}
		media = total/elementos;
		this.resistencia = media;
	}
	
	public int getTreinosFinalizados(){
		return this.treinosFinalizados;
	}
	
	public double getResistencia() {
		return this.resistencia;
	}
	
	
}
