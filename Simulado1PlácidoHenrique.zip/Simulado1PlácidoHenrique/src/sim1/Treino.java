package sim1;

public class Treino {
	private double distancia;
	private int tempoEsperado;
	private int tempoGasto;
	private String descricao;
	private String status = "não iniciado";
	private int indice;
	private int resistencia;
	
	
	public Treino(int indice,double distancia,int tempoEsperado,String descricao) {
		this.distancia = distancia;
		this.tempoEsperado = tempoEsperado;
		this.descricao = descricao;
	}
	
	public String toStr() {
		return distancia +"Km"+ " - " + tempoEsperado + "min" + " - "+ descricao + " - ";
	}
	
	public void finalizar(int tempoGasto) {
		this.status = "finalizado";
		this.tempoGasto = tempoGasto;
		if (this.tempoEsperado - this.tempoGasto < 0) {
			this.resistencia = -1;
		}
		else if (this.tempoEsperado - this.tempoGasto > 0) {
			this.resistencia = 1;
		}
		else {
			this.resistencia = 0;
		}
	}
	
	public int getResistencia() {
		return this.resistencia;
	}
		
}

