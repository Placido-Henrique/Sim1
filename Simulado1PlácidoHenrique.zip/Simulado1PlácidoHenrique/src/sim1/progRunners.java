package sim1;

public class progRunners {
	private Corredor[] corredores;
	private int contador = 0;
	
	public progRunners() {
		this.corredores = new Corredor[1000];
		contador ++;
	}
	
	public void cadastrarCorredor(String nome, String cpf, int anoNascimento) {
		this.corredores[contador] = new Corredor(nome, cpf, anoNascimento);
	}
	
	public String listarCorredores() {
		String saida = "";
		for (int i = 0; i < corredores.length; i++) {
			if (corredores[i] == null){	
			}
			else {
				saida += corredores[i].toStr()+"\n";
				
			}
		}
		return saida;
	}
	
	public Corredor achaCorredor(String cpf){
		
		for (int i = 0; i < corredores.length; i++) {
			if (corredores[i] == null ){	
			}
			else if (this.corredores[i].getCpf().equals(cpf)) {
				return corredores[i];
			}
		}
		return null;			
	}
	
	public void cadastrarTreinoCorredor(String cpf, double distancia, int tempoEsperado, String descricao) {
		this.achaCorredor(cpf).cadastraTreino(distancia, tempoEsperado, descricao);
	}
	
	public void finalizarTreino(String cpf, int indice, int tempoGasto) {
		this.achaCorredor(cpf).finalizaTreino(indice,tempoGasto);
		
	}
	public int contarTreinosFinalizadosCorredor(String cpf){
		return this.achaCorredor(cpf).getTreinosFinalizados();
	}
	
	public double resistenciaCorredor(String cpf) {
		return this.achaCorredor(cpf).getResistencia();
	}

}
